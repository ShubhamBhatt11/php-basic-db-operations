<?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") 
    {
        // collect value of input field
        $fname=$_REQUEST['firstname'];
        $lname=$_REQUEST['lastname'];
        $em = $_REQUEST['n_email'];
        $pwd=  $_REQUEST['n_password'];
            echo "Welcome User<br>";
            echo "<br>";
            echo "Name = ".$fname." ".$lname;
            echo "<br>";
            echo "Email = ".$em ;
            echo "<br>";
            echo "Password = ".$pwd ;
            echo "<br>";
    }

$servername = "localhost";
$username = "root";
$password = "";

// Create connection
$conn = mysqli_connect($servername, $username, $password);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully to DB";  
echo"<br>";   

// Create database
$sql = "use myDB";
if (mysqli_query($conn, $sql)) 
{
    echo "Database selected successfully<br>";
} 
else 
{
    echo "Error selecting database: " . mysqli_error($conn);
}
// sql to create table
$sql = "CREATE TABLE if not exists register_user(first_name varchar(20) not null,last_name varchar(20) not null,email varchar(20) primary key,password varchar(20) not null)";
    
    if (mysqli_query($conn, $sql)) 
    {
        echo "Table register_user created successfully<br>";
    } 
    else 
    {
        echo "Error creating table: " . mysqli_error($conn);
    }

           
    
        echo "new user registration : <br>";
        $stmt = mysqli_stmt_init($conn);
        $query="insert into register_user values(?,?,?,?)";
        if ( mysqli_stmt_prepare($stmt,$query) ) 
        {
            

            /* bind parameters for markers */
            mysqli_stmt_bind_param($stmt, "ssss",$fname,$lname, $em,$pwd);

            /* execute query */
            mysqli_stmt_execute($stmt);

            /* bind result variables */
        // mysqli_stmt_bind_result($stmt,$result,);

            /* fetch value */
        // mysqli_stmt_fetch($stmt);
            //echo gettype($stmt)."<br>";

            printf("Row inserted Success");
        }
        
     mysqli_stmt_close($stmt);
    /* close connection */
    mysqli_close($conn);
    ?>   
        


       

           


        
    
    
    
