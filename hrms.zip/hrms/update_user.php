<?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") 
    {
        // collect value of input field
            $firstname = $_POST['firstname'];
            $lastname = $_POST['lastname'];
            $email = $_POST['email'];
            $password1 = $_POST['password'];
            $mobile = $_POST['mobile'];
            $location = $_POST['location'];
            echo "Welcome User<br>";
            echo "<br>";
            echo "Username = ".$email;
            echo "<br>";
            echo "Password = ".$password1;
            echo "<br>";
           // session_start();
            //$_SESSION["uname"] =$email;    
    }
    session_start();
    $em=$_SESSION['email'];
    echo $em."<br>";


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dbsoft";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);


// Check connection
if (!$conn) 
{
    die("Connection failed: " . mysqli_connect_error());
}
$sql = "UPDATE user
        SET password = '$password1',first_name='$firstname',
        last_name='$lastname',mobile='$mobile',location='$location'
        WHERE email = '$em' ";
if (mysqli_query($conn, $sql)) 
{
    echo "Record updated successfully";
} 
else 
{
    echo "Error updating record: " . mysqli_error($conn);
}



mysqli_close($conn);

    
   
?>


