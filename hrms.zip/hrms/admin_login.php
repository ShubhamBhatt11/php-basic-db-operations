<?php

//
session_start();
//echo session_status();
echo "<br>";


    
    if ($_SERVER["REQUEST_METHOD"] == "POST") 
    {
        // collect value of input field
            $email = $_POST['n_email'];
            $pass = $_POST['n_password'];
            echo "Welcome User<br>";
            echo "<br>";
            echo "Username = ".$email;
            echo "<br>";
            echo "Password = ".$pass;
            echo "<br>";
    }
$servername = "localhost";
$username = "root";
$password = "";

// Create connection
$conn = mysqli_connect($servername, $username, $password);

// Check connection
if (!$conn) 
{
    die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully to DB";  
echo"<br>";   

// Create database
$sql = "use DBsoft";
if (mysqli_query($conn, $sql)) 
{
    echo "Database selected successfully<br>";
} 
else 
{
    echo "Error selecting database: " . mysqli_error($conn);
}
// sql to create table
$sql = "CREATE TABLE if not exists admin(email varchar(20) primary key,
password varchar(20) not null)";
    
    if (mysqli_query($conn, $sql)) 
    {
        echo "Table user created successfully<br>";
    } 
    else 
    {
        echo "Error creating table: " . mysqli_error($conn);
    }

    /* create a prepared statement */
$stmt = mysqli_stmt_init($conn);
$query="SELECT email, password  FROM admin WHERE email=?";
if ( mysqli_stmt_prepare($stmt,$query) ) 
{
    

    /* bind parameters for markers */
    mysqli_stmt_bind_param($stmt, "s", $email);

    /* execute query */
    mysqli_stmt_execute($stmt);

    /* bind result variables */
    mysqli_stmt_bind_result($stmt,$un,$pswd);

    /* fetch value */
    mysqli_stmt_fetch($stmt);
    //echo gettype($stmt)."<br>";
    echo "Data from table : <br>";
    echo "username-".$un."<br>";
    echo "password-".$pswd;
    echo "<br>";
    

     if($email == $un and $pass == $pswd )//                                       //if( (strmp($email,$un) and strcmp($pass,$pswd))==0 )
    {
        echo "<h1>successfully logged in</h1><br>";
        echo "<a href='show_users.php'>Show users</a><br>";
        echo "<a href='add_user.html'>Add a user</a>";
        header("Cache-Control: no cache");                  //  to prevent form resubmission
       // session_cache_limiter("private_no_expire");         //
    
        
        
    }
    else
    {
        echo "<h1>could not log in</h1>";
    }
    

   // printf("you entered %s = existing in db: %s\n", $user, $result);

    /* close statement */
    mysqli_stmt_close($stmt);
    /* close connection */
    mysqli_close($conn);
}

   
 ?>
