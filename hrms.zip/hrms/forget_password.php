<?php


if ($_SERVER["REQUEST_METHOD"] == "POST") 
    {
        // collect value of input field
            $email=$_REQUEST['n_email'];
            //$pass=$_REQUEST['n_password'];
            echo "Welcome User<br>";
            //echo "<br>";
            echo "Username = ".$email;
            echo "<br>";
           // echo "Password = ".$pass;
           // echo "<br>";
    }
$servername = "localhost";
$username = "root";
$password = "";

// Create connection
$conn = mysqli_connect($servername, $username, $password);

// Check connection
if (!$conn) 
{
    die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully to DB";  
echo"<br>";   

// Create database
$sql = "use dbsoft";
if (mysqli_query($conn, $sql)) 
{
    echo "Database selected successfully<br>";
} 
else 
{
    echo "Error selecting database: " . mysqli_error($conn);
}
// sql to create table
$sql = "CREATE TABLE if not exists user(email varchar(20) primary key,
password varchar(20) not null,
first_name varchar(20) not null,
last_name varchar(20) not null,
leaves int default 0,
mobile varchar(10) default '0',
location varchar(10) default '0')";
    
    if (mysqli_query($conn, $sql)) 
    {
        echo "Table user created successfully<br>";
    } 
    else 
    {
        echo "Error creating table: " . mysqli_error($conn);
    }

    /* create a prepared statement */
$stmt = mysqli_stmt_init($conn);
$query="SELECT email FROM user WHERE email=?";
if ( mysqli_stmt_prepare($stmt,$query) ) 
{
    

    /* bind parameters for markers */
    mysqli_stmt_bind_param($stmt, "s", $email);

    /* execute query */
    mysqli_stmt_execute($stmt);

    /* bind result variables */
    mysqli_stmt_bind_result($stmt,$em);

    /* fetch value */
    mysqli_stmt_fetch($stmt);
    //echo gettype($stmt)."<br>";
    echo "Data from table : <br>";
    echo "username-".$em."<br>";
   
    if($em==$email)
    {
        echo "<h1>Your email will be sent shortly</h1>";
    }
    else
    {
        echo "<h1>This is an invalid email</h1>";
    }
   
    mysqli_stmt_close($stmt);
}


/* close connection */
mysqli_close($conn);
?>