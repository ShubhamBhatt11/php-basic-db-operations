<?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") 
    {
        // collect value of input field
        $fname=$_REQUEST['firstname'];
        $lname=$_REQUEST['lastname'];
        $em = $_REQUEST['email'];
        $pwd=  $_REQUEST['password'];
        $mobile=  $_REQUEST['mobile'];
        $location=  $_REQUEST['location'];
            echo "Welcome User<br>";
            echo "<br>";
            echo "Name = ".$fname." ".$lname;
            echo "<br>";
            echo "Email = ".$em ;
            echo "<br>";
            echo "Password = ".$pwd ;
            echo "<br>";
            echo "Mobile = ".$mobile ;
            echo "<br>";
            echo "Location = ".$location ;
            echo "<br>";
    }

$servername = "localhost";
$username = "root";
$password = "";

// Create connection
$conn = mysqli_connect($servername, $username, $password);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully to DB";  
echo"<br>";   

// Create database
$sql = "use dbsoft";
if (mysqli_query($conn, $sql)) 
{
    echo "Database selected successfully<br>";
} 
else 
{
    echo "Error selecting database: " . mysqli_error($conn);
}


// sql to create table
$sql = "CREATE TABLE if not exists user(email varchar(20) primary key,
password varchar(20) not null,
first_name varchar(20) not null,
last_name varchar(20) not null,
leaves int default 0,
mobile varchar(10) default '0',
location varchar(10) default '0')";
    
    if (mysqli_query($conn, $sql)) 
    {
        echo "Table user created successfully<br>";
    } 
    else 
    {
        echo "Error creating table: " . mysqli_error($conn);
    }
    

           
    
        echo "new user registration : <br>";
        $stmt = mysqli_stmt_init($conn);
        $query="insert into user (email,password,first_name,last_name,mobile,location)
        values(?,?,?,?,?,?)";
        if ( mysqli_stmt_prepare($stmt,$query) ) 
        {
            

            /* bind parameters for markers */
            mysqli_stmt_bind_param($stmt, "ssssss",$em,$pwd,$fname,$lname,$mobile,$location);

            /* execute query */
            mysqli_stmt_execute($stmt);

            /* bind result variables */
        // mysqli_stmt_bind_result($stmt,$result,);

            /* fetch value */
        // mysqli_stmt_fetch($stmt);
            //echo gettype($stmt)."<br>";

            echo "Row inserted Success";
        }
        
     //mysqli_stmt_close($stmt);
    /* close connection */
    mysqli_close($conn);
    ?>   
        


       

           


        
    
    
    
