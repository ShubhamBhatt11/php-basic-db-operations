<?php
    echo "I am from Edit Profile <br>";
    session_start();
?>

<!DOCTYPE html>
<html>
    <head>
        <title>edit_profile</title>
    </head>
    <body>
        <form action="update_user.php" class="user" name="myForm" method="POST">
            <div class="form-group row">
              <div class="col-sm-6 mb-3 mb-sm-0">
                  First name
                <input type="text" value="<?php echo $_SESSION['firstname'] ?>" class="form-control form-control-user" id="exampleFirstName" placeholder="First Name" name="firstname" required>
              </div>
              <div class="col-sm-6">
                  Last Name
                <input type="text" value="<?php echo $_SESSION['lastname'] ?>" class="form-control form-control-user" id="exampleLastName" placeholder="Last Name" name="lastname" required> 
              </div>
            </div>
            <div class="form-group">
                Email
              <input type="email" value="<?php echo $_SESSION['email'] ?>"  class="form-control form-control-user" id="exampleInputEmail" placeholder="Email Address" name="email" required>
            </div>
            <div class="form-group row">
                Password
              <div class="col-sm-6 mb-3 mb-sm-0">
                <input type="text" value="<?php echo $_SESSION['password'] ?>" class="form-control form-control-user" id="exampleInputPassword" placeholder="Password" name="password" required>
              </div>
            <div class="col-sm-6 mb-3 mb-sm-0">
                Mobile
                <input type="text" value="<?php echo $_SESSION['mobile'] ?>" class="form-control form-control-user" id="mob" placeholder="Mobile" name="mobile" required>
              </div>
              <div class="col-sm-6 mb-3 mb-sm-0">
                  Location
                <input type="text" value="<?php echo $_SESSION['location'] ?>" class="form-control form-control-user" id="loc" placeholder="Location" name="location" required>
              </div>
            <input type="submit"  value="Update Records" class="btn btn-primary btn-user btn-block" onsubmit="return validate_email()">
           
            
            <hr>
          </form>
    </body>
</html>