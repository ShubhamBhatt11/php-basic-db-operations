<?php
    session_start();
    print_r($_SESSION);
    //session_destroy();
    echo "<br>";
    echo "<a href='edit_profile.php'>Edit Profile</a>";
    
?>