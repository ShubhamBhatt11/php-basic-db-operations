<?php
    session_start();
   /* $_SESSION["firstname"]=$fn;
    $_SESSION["lastname"]=$ln;
    $_SESSION['email']=$un;
    $_SESSION['password']
    $_SESSION['leaves']
    $_SESSION['mobile']=$mob;
    $_SESSION['location']=$loc;
    */

    echo "Welcome ".$_SESSION["firstname"]." ".$_SESSION["lastname"];

    echo "<br>";

    echo "<a href='profile.php'>Profile</a>"; 

?>
